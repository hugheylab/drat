# zeitzeiger 2.1.1
* Removed formerly deprecated functions.

# zeitzeiger 2.1.0
* Switched to `data.table`.

# zeitzeiger 2.0.4
* Removed dependency on the `metapredict` package.

# zeitzeiger 2.0.3
* Revised code to not need `globalVariables()` in order to pass R CMD check without notes. 

# zeitzeiger 2.0.2
* Added `pkgdown` site.
* Updated documentation.
