## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ---- eval = FALSE------------------------------------------------------------
#  metapredict::installCustomCdfPackages(
#    c('hgu95av2hsentrezgcdf', 'hgu133plus2hsentrezgcdf'))

