# limorhyde 1.0.2
* Updated style to match lab standard.

# limorhyde 1.0.1
* Updated external dataset for vignette.

# limorhyde 0.1.3
* Updated vignette to not use deprecated ggplot syntax.

# limorhyde 0.1.2
* Added `pkgdown` site.
* Updated documentation.
