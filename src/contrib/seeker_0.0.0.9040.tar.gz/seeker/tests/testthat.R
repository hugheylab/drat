library(testthat)
library(seeker)

test_check("seeker")
