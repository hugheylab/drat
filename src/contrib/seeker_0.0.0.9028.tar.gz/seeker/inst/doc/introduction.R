## ---- setup, include = FALSE--------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = '#>')

## ---- code = readLines(system.file('extdata', 'params_template.yml', package = 'seeker')), eval = FALSE----
#  study: '' # [string]
#  metadata:
#    run: TRUE # [logical]
#    bioproject: '' # [string]
#    # include # [named list or NULL]
#      # colname # [string]
#      # values # [vector]
#    # exclude # [named list or NULL]
#      # colname # [string]
#      # values # [vector]
#  fetch:
#    run: TRUE # [logical]
#    # overwrite # [logical or NULL]
#    # ascpCmd # [string or NULL]
#    # ascpArgs # [character vector or NULL]
#    # ascpPrefix # [string or NULL]
#  trimgalore:
#    run: TRUE # [logical]
#    # cmd # [string or NULL]
#    # args # [character vector or NULL]
#  fastqc:
#    run: TRUE # [logical]
#    # cmd # [string or NULL]
#    # args # [character vector or NULL]
#  salmon:
#    run: TRUE # [logical]
#    indexDir: '' # [string]
#    # cmd # [string or NULL]
#    # args # [character vector or NULL]
#  multiqc:
#    run: TRUE # [logical]
#    # cmd # [string or NULL]
#    # args # [character vector or NULL]
#  tximport:
#    run: TRUE # [logical]
#    tx2gene:
#      # [named list or NULL]
#      dataset: 'mmusculus_gene_ensembl' # [string]
#      version: 104 # [number; latest version is 104 as of Oct 2021]
#    countsFromAbundance: '' # [string]
#    # ignoreTxVersion # [logical or NULL]

## ---- code = readLines(system.file('extdata', 'run_seeker.R', package = 'seeker')), eval = FALSE----
#  doParallel::registerDoParallel(cores = 4)
#  
#  cArgs = commandArgs(TRUE)
#  yamlPath = cArgs[1L]
#  parentDir = cArgs[2L]
#  
#  params = yaml::read_yaml(yamlPath)
#  seeker::seeker(params, parentDir)

