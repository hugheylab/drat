library(testthat)
library(simphony)

test_check("simphony")
