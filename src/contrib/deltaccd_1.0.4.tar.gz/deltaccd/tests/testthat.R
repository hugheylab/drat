library(testthat)
library(deltaccd)

test_check('deltaccd')
