library('testthat')
library('limorhyde')

test_check('limorhyde')
