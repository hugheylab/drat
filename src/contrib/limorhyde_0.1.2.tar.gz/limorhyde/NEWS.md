# limorhyde 0.1.2
* Added `pkgdown` site.
* Updated documentation.
