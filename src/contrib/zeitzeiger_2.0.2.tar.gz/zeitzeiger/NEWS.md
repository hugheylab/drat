# zeitzeiger 2.0.2
* Added `pkgdown` site.
* Updated documentation.
