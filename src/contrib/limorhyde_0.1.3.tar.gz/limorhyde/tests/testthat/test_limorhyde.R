test_that('addIntercept', {
  # Put testing logic and expectations here!
})
