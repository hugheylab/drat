# simphony 1.0.0
* Updated to match lab style standards.

# simphony 1.0.0
* Solidified the current version as official 1.0.0 release.

# simphony 0.1.10
* Removed use of `get()` in `data.table`, which is deprecated.

# simphony 0.1.9
* Revised code to not need `globalVariables()` in order to pass R CMD check.

# simphony 0.1.8
* Switched to using `data.table::set` in a few places for speed.

# simphony 0.1.7
* Changed whitespace.

# simphony 0.1.6
* Added `pkgdown` site.
* Updated documentation.
