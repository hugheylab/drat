test_that('getAscpCmd', {
  ascpCmdObs = getAscpCmd()

  ascpCmdExp = snapshot(ascpCmdObs, file.path(dataDir, paste0(os, '_get_ascp_cmd_output.qs')))

  expect_equal(ascpCmdObs, ascpCmdExp)
})

test_that('getAscpArgs', {
  ascpArgsObs = getAscpArgs()

  ascpArgsExp = snapshot(ascpArgsObs, file.path(dataDir, paste0(os, '_get_ascp_args_output.qs')))

  expect_equal(ascpArgsObs, ascpArgsExp)
})
