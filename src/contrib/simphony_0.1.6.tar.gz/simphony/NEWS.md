# simphony 0.1.6
* Added `pkgdown` site.
* Updated documentation.
