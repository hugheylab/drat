# phers 0.0.2
* Set keys for data.tables.

# phers 0.0.1
* Updated code and documentation.
