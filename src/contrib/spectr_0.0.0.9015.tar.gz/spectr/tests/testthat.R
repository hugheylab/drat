library(testthat)
library(spectr)
library(data.table)

test_check('spectr')
