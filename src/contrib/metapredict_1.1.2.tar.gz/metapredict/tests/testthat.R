library('testthat')
library('metapredict')

test_check('metapredict')
