# tipa 1.0.8
* Switched from optimr to optimx.

# tipa 1.0.7
* Fixed code style issue caught by lintr.

# tipa 1.0.6
* Fixed syntax to adhere to lab code style.

# tipa 1.0.5
* Removed `write.csv()` from examples.

# tipa 1.0.4
* Moved examples to roxygen documentation.

# tipa 1.0.3
* Added `pkgdown` site.
* Updated documentation.
