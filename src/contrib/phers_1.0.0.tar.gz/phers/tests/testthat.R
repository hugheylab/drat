library(testthat)
library(phers)

test_check('phers')
