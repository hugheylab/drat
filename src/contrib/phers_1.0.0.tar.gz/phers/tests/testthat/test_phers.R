weightsPrevTest = data.table(
  phecode = c('001', '002', '003', '004'),
  pred = c(1 / 4, 2 / 4, 1 / 4, 1 / 4), w = -log10(c(1 / 4, 2 / 4, 1 / 4, 1 / 4)))

weightsProbTest = data.table(
  person_id = c(1, rep(2L, 2), 3, 4),
  phecode = c('001', '002', '003', '002', '004'), pred = 0.5, w = -log10(0.5))

icdPhecodeMapTest = data.table(
  icd = c('001', '002', '003', '004', '005', '006'),
  phecode = c('001', '002', '003', '004', '005', '006'), flag = 9)

scoresPrevExp = data.table(
  person_id = seq_len(4),
  disease_id = rep(1, 4),
  score = c(0.60206, 0.90309, 0.30103, 0.00000))
setkeyv(scoresPrevExp, c('person_id', 'disease_id'))

scoresLgExp = data.table(
  person_id = seq_len(4),
  disease_id = rep(1, 4),
  score = c(0.30103, 0.60206, 0.30103, 0.00000))
setkeyv(scoresLgExp, c('person_id', 'disease_id'))

test_that('getPhecodeOccurrences output', {

  resObs = getPhecodeOccurrences(
    icdTest, icdPhecodeMap = icdPhecodeMapTest, dxIcd = dxIcdTest)
  setkey(resObs)
  resExp = phecodeOccurrencesTest

  expect_equal(resObs, resExp, ignore_attr = TRUE)
})


test_that('getPhecodeOccurrences output (dxIcd = NULL)', {

  resObs = getPhecodeOccurrences(
    icdTest, icdPhecodeMap = icdPhecodeMapTest, dxIcd = NULL)
  setkey(resObs)
  resExp = data.table(
    person_id = c(1, rep(2L, 3), 3, rep(4L, 3)),
    phecode = c('001', '002', '003', '005', '002', '004', '005', '006'),
    entry_date = c(rep(as.Date('2000/01/01'), 6),
                   c(as.Date('2000/01/01'), as.Date('2000/01/02'))))
  setkey(resExp)

  expect_equal(resObs, resExp)
})


test_that('getPhecodeOccurrences args error', {

  # ICD is numeric
  icdTestErr = copy(icdTest)
  icdTestErr[, icd := as.numeric(icd)]
  expect_error(getPhecodeOccurrences(icdTestErr))

  # no ICD flags
  icdTestErr = icdTest[, .(person_id, icd)]
  expect_error(getPhecodeOccurrences(icdTestErr))
})


test_that('getScores output (population weights)', {

  resObs = getScores(
    demosTest, phecodeOccurrencesTest, weightsPrevTest, diseasePhecodeMapTest)
  resExp = scoresPrevExp
  expect_equal(resObs, resExp, ignore_attr = TRUE)
})


test_that('getScores output (personalized weights)', {

  resObs = getScores(
    demosTest, phecodeOccurrencesTest, weightsProbTest, diseasePhecodeMapTest)
  resExp = scoresLgExp
  expect_equal(resObs, resExp, ignore_attr = TRUE)
})


test_that('getScores args error', {

  # no column named person_id demos
  demosTestErr = copy(demosTest)
  setnames(demosTestErr, 'person_id', 'person_id_Err')
  expect_error(getScores(demosTestErr, phecodeOccurrencesTest, weightsPrevTest,
                         diseasePhecodeMapTest))

  # no column named person_id in phecodes
  phecodeOccurrencesTestErr = copy(phecodeOccurrencesTest)
  setnames(phecodeOccurrencesTestErr, 'person_id', 'person_id_Err')
  expect_error(getScores(demosTestErr, phecodeOccurrencesTestErr, weightsPrevTest,
                         diseasePhecodeMapTest))

  # phecodes are numeric
  phecodeOccurrencesTestErr = copy(phecodeOccurrencesTest)
  phecodeOccurrencesTestErr[, phecode := as.numeric(phecode)]
  expect_error(getScores(demosTestErr, phecodeOccurrencesTestErr, weightsPrevTest,
                         diseasePhecodeMapTest))

  # phecodes are numeric in weights
  weightsTestErr = copy(weightsPrevTest)
  weightsTestErr[, phecode := as.numeric(phecode)]
  expect_error(getScores(demosTestErr, phecodeOccurrencesTest, weightsTestErr,
                         diseasePhecodeMapTest))
})


test_that('getResidualScores output', {
  resObs = getResidualScores(demosTest2, scoresTest, formTest)
  resExp = snapshot(resObs, file.path(dataDir, 'get_residual_scores_output.qs'))

  expect_equal(resObs, resExp)
})


test_that('phers output (prevalence)', {

  resObs = phers(
    demosTest,  icdTest, diseasePhecodeMapTest,
    icdPhecodeMap = icdPhecodeMapTest, dxIcd = dxIcdTest)
  resObs = lapply(resObs, setkey)

  resExp = list(
    phecodeOccurrences = phecodeOccurrencesTest,
    weights = weightsExp,
    scores = scoresPrevExp)

  expect_equal(resObs, resExp, ignore_attr = TRUE)
})

test_that('phers output (logistic)', {

  resObs = phers(
    demosTest,  icdTest, diseasePhecodeMapTest,
    method ='logistic', methodFormula = formTest,
    icdPhecodeMap = icdPhecodeMapTest, dxIcd = dxIcdTest)
  resObs = lapply(resObs, setkey)

  weightsExp = snapshot(
    resObs$weights, file.path(dataDir, 'get_weights_logistic_output.qs'))
  setkey(weightsExp)

  resExp = list(
    phecodeOccurrences = phecodeOccurrencesTest,
    weights = weightsExp,
    scores = scoresLgExp)

  expect_equal(resObs, resExp, ignore_attr = TRUE)
})

test_that('phers output (calculate residual scores)', {

  resObs = phers(
    demosTest, icdTest, diseasePhecodeMapTest,
    icdPhecodeMap = icdPhecodeMapTest, dxIcd = dxIcdTest,
    residScoreFormula = formTest)
  resObs = lapply(resObs, setkey)

  rScoresExp = data.table(
    person_id = seq_len(4),
    disease_id = rep(1, 4),
    score = c(0.60206, 0.90309, 0.30103, 0.00000),
    resid_score = c(0.4472136, 1.3416408, -0.4472136, -1.3416408))

  resExp = list(
    phecodeOccurrences = phecodeOccurrencesTest,
    weights = weightsExp,
    scores = rScoresExp)

  expect_equal(resObs, resExp, ignore_attr = TRUE)
})
