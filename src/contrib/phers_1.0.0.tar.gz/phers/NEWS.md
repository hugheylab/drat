# phers 1.0.0
* Added methods to calculate weights based on logistic, log-linear, and Cox proportional hazards regression.

# phers 0.0.4
* Updated documentation with the version of `hpoPhecodeMap`.

# phers 0.0.3
* Set better key for residual scores table.
* Switched to `lm()` instead of `glm()` for speed.
* Simplified genetic association table for genotypic model.
* Switched from `vid` to `variant_id` for clarity and consistency.

# phers 0.0.2
* Set keys for data.tables.

# phers 0.0.1
* Updated code and documentation.
