## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  fig.align = 'center',
  fig.retina = 2,
  eval = FALSE)

foreach::registerDoSEQ()

## -----------------------------------------------------------------------------
#  library('limorhyde2')
#  # txi = ?
#  # metadata = ?

## -----------------------------------------------------------------------------
#  keep = rowSums(edgeR::cpm(txi$counts) >= 1) >= 0.5 * ncol(txi$counts)

## -----------------------------------------------------------------------------
#  y = DESeq2::DESeqDataSetFromTximport(txi, metadata, ~1)
#  y = y[keep, ]
#  
#  fit = getModelFit(y, metadata, ..., method = 'deseq2') # replace '...' as appropriate for your data

## -----------------------------------------------------------------------------
#  y = edgeR::DGEList(txi$counts[keep, ])
#  y = edgeR::calcNormFactors(y)
#  
#  fit = getModelFit(y, metadata, ..., method = 'voom') # replace '...' as appropriate for your data

