## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = '#>')

## ---- code = readLines(system.file('extdata', 'params_template.yml', package = 'seeker')), eval = FALSE----
#  study: '' # [string]
#  metadata:
#    run: TRUE # [logical]
#    bioproject: '' # [string]
#    # include # [named list or NULL]
#      # colname # [string]
#      # values # [vector]
#    # exclude # [named list or NULL]
#      # colname # [string]
#      # values # [vector]
#  fetch:
#    run: TRUE # [logical]
#    # keep # [logical or NULL]
#    # overwrite # [logical or NULL]
#    # ascpCmd # [string or NULL]
#    # ascpArgs # [character vector or NULL]
#    # ascpPrefix # [string or NULL]
#  trimgalore:
#    run: TRUE # [logical]
#    # keep # [logical or NULL]
#    # cmd # [string or NULL]
#    # args # [character vector or NULL]
#  fastqc:
#    run: TRUE # [logical]
#    # keep # [logical or NULL]
#    # cmd # [string or NULL]
#    # args # [character vector or NULL]
#  salmon:
#    run: TRUE # [logical]
#    indexDir: '' # [string]
#    # keep # [logical or NULL]
#    # cmd # [string or NULL]
#    # args # [character vector or NULL]
#  multiqc:
#    run: TRUE # [logical]
#    # cmd # [string or NULL]
#    # args # [character vector or NULL]
#  tximport:
#    run: TRUE # [logical]
#    tx2gene:
#      # [named list or NULL]
#      species: 'mmusculus' # [string]
#      # version # [number or NULL]
#    countsFromAbundance: '' # [string]
#    # ignoreTxVersion # [logical or NULL]

## ---- code = readLines(system.file('extdata', 'run_seeker.R', package = 'seeker')), eval = FALSE----
#  doParallel::registerDoParallel()
#  
#  cArgs = commandArgs(TRUE)
#  yamlPath = cArgs[1L]
#  parentDir = cArgs[2L]
#  
#  params = yaml::read_yaml(yamlPath)
#  seeker::seeker(params, parentDir)

